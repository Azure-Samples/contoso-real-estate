/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(globalThis["webpackChunkwebsite"] = globalThis["webpackChunkwebsite"] || []).push([["__comp---site-src-pages-api-js-48-d-376"],{

/***/ "./src/pages/api.js":
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ App)\n/* harmony export */ });\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(\"./node_modules/react/index.js\");\n/* harmony import */ var _docusaurus_useDocusaurusContext__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(\"./node_modules/@docusaurus/core/lib/client/exports/useDocusaurusContext.js\");\n/* harmony import */ var _theme_Layout__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(\"./node_modules/@docusaurus/theme-classic/lib/theme/Layout/index.js\");\n/* harmony import */ var swagger_ui_react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(\"./node_modules/swagger-ui-react/index.js\");\n/* harmony import */ var swagger_ui_react_swagger_ui_css__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(\"./node_modules/swagger-ui-react/swagger-ui.css\");\nfunction App(){const{siteConfig}=(0,_docusaurus_useDocusaurusContext__WEBPACK_IMPORTED_MODULE_1__[\"default\"])();return/*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_theme_Layout__WEBPACK_IMPORTED_MODULE_2__[\"default\"],{title:`OpenAPI Specification for Contoso Real Estate`,description:\"Documentation auto-generated for the OpenAPI YAML using swagger-ui-react\"},/*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(\"main\",null,/*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(swagger_ui_react__WEBPACK_IMPORTED_MODULE_3__[\"default\"],{url:\"yml/openapi.yaml\"})));}//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9zcmMvcGFnZXMvYXBpLmpzIiwibWFwcGluZ3MiOiI7Ozs7Ozs7OztBQUFBIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vd2Vic2l0ZS8uL3NyYy9wYWdlcy9hcGkuanM/ZWFmMyJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QgZnJvbSAncmVhY3QnO1xuaW1wb3J0IHVzZURvY3VzYXVydXNDb250ZXh0IGZyb20gJ0Bkb2N1c2F1cnVzL3VzZURvY3VzYXVydXNDb250ZXh0JztcbmltcG9ydCBMYXlvdXQgZnJvbSAnQHRoZW1lL0xheW91dCc7XG5cbmltcG9ydCBTd2FnZ2VyVUkgZnJvbSBcInN3YWdnZXItdWktcmVhY3RcIjtcbmltcG9ydCAnc3dhZ2dlci11aS1yZWFjdC9zd2FnZ2VyLXVpLmNzcyc7XG5cblxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gQXBwKCkge1xuXG4gICAgY29uc3Qge3NpdGVDb25maWd9ID0gdXNlRG9jdXNhdXJ1c0NvbnRleHQoKTtcbiAgICByZXR1cm4gKFxuICAgICAgPExheW91dFxuICAgICAgICB0aXRsZT17YE9wZW5BUEkgU3BlY2lmaWNhdGlvbiBmb3IgQ29udG9zbyBSZWFsIEVzdGF0ZWB9XG4gICAgICAgIGRlc2NyaXB0aW9uPVwiRG9jdW1lbnRhdGlvbiBhdXRvLWdlbmVyYXRlZCBmb3IgdGhlIE9wZW5BUEkgWUFNTCB1c2luZyBzd2FnZ2VyLXVpLXJlYWN0XCI+XG4gICAgICAgIDxtYWluPlxuICAgICAgICAgICAgPFN3YWdnZXJVSSB1cmw9XCJ5bWwvb3BlbmFwaS55YW1sXCIgLz5cbiAgICAgICAgPC9tYWluPlxuICAgICAgPC9MYXlvdXQ+XG4gICAgKTtcbiAgfVxuIl0sIm5hbWVzIjpbXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///./src/pages/api.js\n");

/***/ }),

/***/ "?2128":
/***/ (() => {

/* (ignored) */

/***/ })

}]);